const fs = require('fs');

const waButton = `
<!-- Floating WhatsApp Button -->
<a href="https://wa.me/917273884244?text=Hi!%20I'm%20inquiring%20about%20the%20elite%20programs%20at%20Red%20Dragon.%20Please%20provide%20more%20details." target="_blank" rel="noopener noreferrer" style="position:fixed; bottom:30px; right:30px; z-index:9999; background-color:#25d366; color:white; border-radius:50px; width:60px; height:60px; display:flex; justify-content:center; align-items:center; box-shadow: 0px 4px 10px rgba(0,0,0,0.3); transition: transform 0.3s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'">
    <svg viewBox="0 0 32 32" style="width:35px; height:35px; fill:currentColor;"><path d="M16.002 0c-8.836 0-16 7.163-16 16 0 2.8.73 5.438 2.016 7.74l-2.016 8.26 8.444-2.22c2.25.116 4.606 2.22 7.556 2.22 8.835 0 16-7.162 16-16s-7.165-16-16-16zm7.886 22.8c-.328.924-1.927 1.76-2.673 1.838-.707.073-1.63.15-4.575-1.07-3.558-1.47-5.836-5.1-6.012-5.334-.176-.233-1.436-1.91-1.436-3.645 0-1.734.904-2.585 1.233-2.935.328-.35.717-.438.956-.438.238 0 .477.002.686.01.218.01.512-.084.802.617.303.738 1.045 2.548 1.14 2.738.095.192.155.414.037.647-.118.232-.178.378-.355.586-.176.21-.368.455-.516.623-.162.18-.335.378-.135.688.2.31 1.436 1.82 2.26.1.1.205.195.313.287 1.205 1.026 2.302 1.3 2.618 1.448.315.148.5.127.688-.06.188-.186.81-1.32 1.02-1.77.21-.45.418-.378.834-.202.417.176 2.637 1.24 3.09 1.447.452.206.753.308.86.48.106.172.106.997-.222 1.92z"/></svg>
</a>
</body>
`;

['index.html', '../website/src/index.html'].forEach(filepath => {
   if (fs.existsSync(filepath)) {
     let html = fs.readFileSync(filepath, 'utf-8');
     html = html.replace('</body>', waButton);
     fs.writeFileSync(filepath, html);
     console.log('Added WhatsApp button to ' + filepath);
   }
});
